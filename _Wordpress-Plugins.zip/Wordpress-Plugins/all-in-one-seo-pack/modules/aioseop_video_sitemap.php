<?php
/**
 * Loads video sitemap class.
 *
 * @package All_in_One_SEO_Pack
 * @since ?
 */

if ( AIOSEOPPRO ) {
	require_once( AIOSEOP_PLUGIN_DIR . 'pro/video_sitemap.php' );
}
